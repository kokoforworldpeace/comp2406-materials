var express = require('express');
var router = express.Router();

var answers = [];
var questions = {
    color: "Favorite color?",
    day: "Favorite day of the week?",
    dog: "Favorite dog breed?"
}


function calcResultsStats(results) {
    var resultsStats = [
	{questionName: "color",
	 questionText: "Favorite color?",
	 labels: ["red", "blue", "yellow", "brown"],
	 values: [5, 7, 2, 0]
	},
	{questionName: "day",
	 questionText: "Favorite day of the week?",
	 labels: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday",
		  "Saturday", "Sunday"],
	 values: [0, 2, 1, 5, 70, 100, 20]
	}
    ];
    return resultsStats;
}


router.get('/', function(req, res) {
    res.render('index', {title: 'COMP 2406 Graphing Demo',
			 questions: questions});
});

router.post('/add', function(req, res) {
    var answer = { firstname: req.body.firstname,
		   color: req.body.color,
		   day: req.body.day}
    answers.push(answer);

    console.log(answer);

    res.redirect('/results');
});

router.get('/results', function(req, res) {
    var stats = calcResultsStats(answers);
    
    res.render('results', { title: 'Survey Results',
			    stats: stats,
			    barwidth: 60
			  });
});

// app.get('/render', function (req, res, next) {
//     res.render('chart', {xlabel: "Months",
//                          ylabel: "Failure rate (%)",
//                          unit: '%',
//                          barwidth: 40,
// 			 pretty: true,
//                          items: [{value: 10, bin: "Jan"},
//                                  {value: 20, bin: "Feb"},
//                                  {value: 40, bin: "Mar"},
//                                  {value: 40, bin: "Apr"},
//                                  {value: 40, bin: "May"},
//                                  {value: 40, bin: "Jun"},
//                                  {value: 40, bin: "Jul"},
//                                  {value: 40, bin: "Aug"},
//                                  {value: 40, bin: "Sep"},
//                                  {value: 40, bin: "Oct"},
//                                  {value: 80, bin: "Nov"},
//                                  {value: 100, bin: "Dec"},
//                                 ]});
// });

module.exports = router;
