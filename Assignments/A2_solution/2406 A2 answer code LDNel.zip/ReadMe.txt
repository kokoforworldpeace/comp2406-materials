To Run:

Start server:
node server.js

To Test:
Use browser to visit:
http://localhost:3000/assignment2.html

Issues:

