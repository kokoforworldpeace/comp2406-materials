The PDF excerpts are from books I'm reviewing as possible recommended texts for future versions of this course.
My current favourite is "Express In Action" by Ethan Hahn (c) 2016 Manning

Please let me know if you find one more helpful than the other.

The weather server example in this section will not run unless you add your own openweathermap.org APP ID key.


Lou Nel